<?php 
//****Automatic Software CreatedBy@BD ****


 if($_SERVER['REQUEST_METHOD']=='POST') { 
	$p_Data_temp_slno=$_POST['Data_temp_slno'];
	$p_Data_temp_ Metric_slno=$_POST['Data_temp_ Metric_slno'];
	$p_Data_temp_ descrip=$_POST['Data_temp_ descrip'];
	$p_Data_temp_ status_block=$_POST['Data_temp_ status_block'];
	$p_Data_temp_ reserved1=$_POST['Data_temp_ reserved1'];
	$p_Data_temp_ reserved2=$_POST['Data_temp_ reserved2'];
	$p_Data_temp_ reserved3=$_POST['Data_temp_ reserved3'];
	$p_Data_temp_ reserved4=$_POST['Data_temp_ reserved4'];
	$p_Data_temp_ reserved5=$_POST['Data_temp_ reserved5'];
	$p_Data_temp_ reserved6=$_POST['Data_temp_ reserved6'];
	$p_Data_temp_ reserved7=$_POST['Data_temp_ reserved7'];
	$p_Data_temp_ reserved8=$_POST['Data_temp_ reserved8'];
	$p_Data_temp_ reserved9=$_POST['Data_temp_ reserved9'];
	$p_Data_temp_ reserved10=$_POST['Data_temp_ reserved10'];
	$p_Data_temp_ reserved11=$_POST['Data_temp_ reserved11'];
	$p_Data_temp_ reserved12=$_POST['Data_temp_ reserved12'];
	$p_Data_temp_ reserved13=$_POST['Data_temp_ reserved13'];
	$p_Data_temp_ reserved14=$_POST['Data_temp_ reserved14'];
	$p_Data_temp_ reserved15=$_POST['Data_temp_ reserved15'];
	$p_Data_temp_ reserved16=$_POST['Data_temp_ reserved16'];
	$p_Data_temp_ reserved17=$_POST['Data_temp_ reserved17'];
	$p_Data_temp_ reserved18=$_POST['Data_temp_ reserved18'];
	$p_Data_temp_ reserved19=$_POST['Data_temp_ reserved19'];
	$p_Data_temp_ reserved20=$_POST['Data_temp_ reserved20'];



	echo "<br> Data_temp_slno :- -----<font color=blue> ".$p_Data_temp_slno."</font>\n";
	echo "<br> Data_temp_ Metric_slno :- -----<font color=blue> ".$p_Data_temp_ Metric_slno."</font>\n";
	echo "<br> Data_temp_ descrip :- -----<font color=blue> ".$p_Data_temp_ descrip."</font>\n";
	echo "<br> Data_temp_ status_block :- -----<font color=blue> ".$p_Data_temp_ status_block."</font>\n";
	echo "<br> Data_temp_ reserved1 :- -----<font color=blue> ".$p_Data_temp_ reserved1."</font>\n";
	echo "<br> Data_temp_ reserved2 :- -----<font color=blue> ".$p_Data_temp_ reserved2."</font>\n";
	echo "<br> Data_temp_ reserved3 :- -----<font color=blue> ".$p_Data_temp_ reserved3."</font>\n";
	echo "<br> Data_temp_ reserved4 :- -----<font color=blue> ".$p_Data_temp_ reserved4."</font>\n";
	echo "<br> Data_temp_ reserved5 :- -----<font color=blue> ".$p_Data_temp_ reserved5."</font>\n";
	echo "<br> Data_temp_ reserved6 :- -----<font color=blue> ".$p_Data_temp_ reserved6."</font>\n";
	echo "<br> Data_temp_ reserved7 :- -----<font color=blue> ".$p_Data_temp_ reserved7."</font>\n";
	echo "<br> Data_temp_ reserved8 :- -----<font color=blue> ".$p_Data_temp_ reserved8."</font>\n";
	echo "<br> Data_temp_ reserved9 :- -----<font color=blue> ".$p_Data_temp_ reserved9."</font>\n";
	echo "<br> Data_temp_ reserved10 :- -----<font color=blue> ".$p_Data_temp_ reserved10."</font>\n";
	echo "<br> Data_temp_ reserved11 :- -----<font color=blue> ".$p_Data_temp_ reserved11."</font>\n";
	echo "<br> Data_temp_ reserved12 :- -----<font color=blue> ".$p_Data_temp_ reserved12."</font>\n";
	echo "<br> Data_temp_ reserved13 :- -----<font color=blue> ".$p_Data_temp_ reserved13."</font>\n";
	echo "<br> Data_temp_ reserved14 :- -----<font color=blue> ".$p_Data_temp_ reserved14."</font>\n";
	echo "<br> Data_temp_ reserved15 :- -----<font color=blue> ".$p_Data_temp_ reserved15."</font>\n";
	echo "<br> Data_temp_ reserved16 :- -----<font color=blue> ".$p_Data_temp_ reserved16."</font>\n";
	echo "<br> Data_temp_ reserved17 :- -----<font color=blue> ".$p_Data_temp_ reserved17."</font>\n";
	echo "<br> Data_temp_ reserved18 :- -----<font color=blue> ".$p_Data_temp_ reserved18."</font>\n";
	echo "<br> Data_temp_ reserved19 :- -----<font color=blue> ".$p_Data_temp_ reserved19."</font>\n";
	echo "<br> Data_temp_ reserved20 :- -----<font color=blue> ".$p_Data_temp_ reserved20."</font>\n";
	//class calling..

	include_once("class.data_template.php");

	$tb_handle=new data_template();

	$tb_handle->Data_temp_slno=$p_Data_temp_slno;
	$tb_handle->Data_temp_ Metric_slno=$p_Data_temp_ Metric_slno;
	$tb_handle->Data_temp_ descrip=$p_Data_temp_ descrip;
	$tb_handle->Data_temp_ status_block=$p_Data_temp_ status_block;
	$tb_handle->Data_temp_ reserved1=$p_Data_temp_ reserved1;
	$tb_handle->Data_temp_ reserved2=$p_Data_temp_ reserved2;
	$tb_handle->Data_temp_ reserved3=$p_Data_temp_ reserved3;
	$tb_handle->Data_temp_ reserved4=$p_Data_temp_ reserved4;
	$tb_handle->Data_temp_ reserved5=$p_Data_temp_ reserved5;
	$tb_handle->Data_temp_ reserved6=$p_Data_temp_ reserved6;
	$tb_handle->Data_temp_ reserved7=$p_Data_temp_ reserved7;
	$tb_handle->Data_temp_ reserved8=$p_Data_temp_ reserved8;
	$tb_handle->Data_temp_ reserved9=$p_Data_temp_ reserved9;
	$tb_handle->Data_temp_ reserved10=$p_Data_temp_ reserved10;
	$tb_handle->Data_temp_ reserved11=$p_Data_temp_ reserved11;
	$tb_handle->Data_temp_ reserved12=$p_Data_temp_ reserved12;
	$tb_handle->Data_temp_ reserved13=$p_Data_temp_ reserved13;
	$tb_handle->Data_temp_ reserved14=$p_Data_temp_ reserved14;
	$tb_handle->Data_temp_ reserved15=$p_Data_temp_ reserved15;
	$tb_handle->Data_temp_ reserved16=$p_Data_temp_ reserved16;
	$tb_handle->Data_temp_ reserved17=$p_Data_temp_ reserved17;
	$tb_handle->Data_temp_ reserved18=$p_Data_temp_ reserved18;
	$tb_handle->Data_temp_ reserved19=$p_Data_temp_ reserved19;
	$tb_handle->Data_temp_ reserved20=$p_Data_temp_ reserved20;
	$tb_handle->insert();	
	echo "<br><br>Data Insertion Done";	
	echo "<script>alert('Insert_Successfully');location.href='data_templateForm.php'</script>"; 

 }
?>