<?php
if (isset($_SESSION['google_access_token'])) {
?>
<div class="row align-items-center">
    <div class="col-12 col-lg-5"></div>
    <div class="col-12 col-lg-7 text-left text-white">
        <font size="5">Download The App Here</font>&nbsp;<a class="btn btn-link" href="https://play.google.com/store/apps/details?id=com.india.tip_teapi" target="_blank" rel="noreferrer" rel="noopener"><i class="fa fa-android" style="font-size: 36px;"></i></a>&nbsp;<a class="btn btn-link" href="#"><i class="fa fa-apple" style="font-size: 36px;"></i></a>
        &nbsp;<font size="4">Hi <?php echo $_SESSION['g_user_first_name']."&nbsp;".$_SESSION['g_user_last_name']; ?></font>&nbsp;
          <a class="dropdown-toggle" role="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="<?php echo $_SESSION['g_user_image'] ?>" class="img-circle img-thumbnail" width="60" height="60">
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="logout.php">Sign Out</a>
          </div>
    </div>
</div>
<?php
}
else if (isset($_SESSION['facebook_access_token'])) {
?>
<div class="row align-items-center">
    <div class="col-12 col-lg-5"></div>
    <div class="col-12 col-lg-7 text-left text-white">
        <font size="5">Download The App Here</font>&nbsp;<a class="btn btn-link" href="https://play.google.com/store/apps/details?id=com.india.tip_teapi" target="_blank" rel="noreferrer" rel="noopener"><i class="fa fa-android" style="font-size: 36px;"></i></a>&nbsp;<a class="btn btn-link" href="#"><i class="fa fa-apple" style="font-size: 36px;"></i></a>
        &nbsp;<font size="4">Hi <?php echo $_SESSION['f_user_name']; ?></font>&nbsp;
          <a class="dropdown-toggle" role="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="<?php echo $_SESSION['f_user_image'] ?>" class="img-circle img-thumbnail" width="60" height="60">
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="logout.php">Sign Out</a>
          </div>
    </div>
</div>
<?php
}
?>