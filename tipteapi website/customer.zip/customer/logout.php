<?php

include_once '../g_config.php';
session_start();

if (isset($_SESSION['google_access_token'])) {
//Reset OAuth access token
$google_client->revokeToken();
}

//Destroy entire session data
session_destroy();

header("Location: http://tipteapi.com");
?>