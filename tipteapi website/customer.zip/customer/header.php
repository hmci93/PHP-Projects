<div class="row">
    <div class="col-lg-3"></div>
    <div class="col-lg-6">
        <div class="row align-items-center text-center">
            <div class="col-lg-3"></div>
            <div class="col-5 col-lg-2" style="align-items: flex-end;"><img src="assets/img/icon-tipteapi@3x2.png" alt=""></div>
            <div class="col-7 col-lg-6"><h1 class="text-left text-white">Tip&nbsp;Teapi</h1></div>
            <div class="col-lg-1"></div>
        </div>
    </div>
    <div class="col-lg-3"></div>
</div>