
-- --------------------------------------------------------

--
-- Table structure for table `user_status`
--

CREATE TABLE `user_status` (
  `us_id` int(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `latitude` varchar(255) NOT NULL,
  `longitude` varchar(255) NOT NULL,
  `likes` varchar(500) NOT NULL,
  `reserved1` varchar(255) DEFAULT NULL,
  `reserved2` varchar(255) DEFAULT NULL,
  `reserved3` varchar(255) DEFAULT NULL,
  `reserved4` varchar(255) DEFAULT NULL,
  `reserved5` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_status`
--

INSERT INTO `user_status` (`us_id`, `username`, `status`, `latitude`, `longitude`, `likes`, `reserved1`, `reserved2`, `reserved3`, `reserved4`, `reserved5`) VALUES
(1, 'user1', 'Available', '0.45619028525534', '1.6012959554735', 'comedy,funny', '', '', '', '', ''),
(2, 'user2', 'Busy', '0.45620698805628', '1.6013814766068', 'comedy,music', '', '', '', '', ''),
(3, 'user3', 'Available', '0.45739761676541', '1.6033379906983', 'comedy,art', '', '', '', '', ''),
(5, 'user5', 'Available', '0.45690721415218', '1.6067710358837', 'funny,dance,music', '', '', '', '', '');
