
-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `block_status` int(5) NOT NULL,
  `reserved1` varchar(255) DEFAULT NULL,
  `reserved2` varchar(255) DEFAULT NULL,
  `reserved3` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `pass`, `block_status`, `reserved1`, `reserved2`, `reserved3`) VALUES
(1, 'admin', 'f0f9f5cc76d8e9fc54522dd7accd6b730c31d57f2716411707ed740b840e8d03', 0, NULL, NULL, NULL);
