
-- --------------------------------------------------------

--
-- Table structure for table `user_bio`
--

CREATE TABLE `user_bio` (
  `id` int(20) NOT NULL,
  `userId` varchar(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `nickName` varchar(1000) DEFAULT NULL,
  `gender` varchar(255) NOT NULL,
  `from_where` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `relationship_status` varchar(255) DEFAULT NULL,
  `primary_lang` varchar(255) NOT NULL,
  `other_lang` varchar(1000) DEFAULT NULL,
  `religion` varchar(255) NOT NULL,
  `zodiac_sign` varchar(255) NOT NULL,
  `height` varchar(255) DEFAULT NULL,
  `complexion` varchar(255) DEFAULT NULL,
  `hobbies` varchar(1000) DEFAULT NULL,
  `edu_quali` varchar(1000) DEFAULT NULL,
  `profession` varchar(1000) DEFAULT NULL,
  `believes` varchar(1000) DEFAULT NULL,
  `about` varchar(1000) DEFAULT NULL,
  `fav_food` varchar(1000) DEFAULT NULL,
  `fav_travel_destn` varchar(1000) DEFAULT NULL,
  `video_cat_liked` varchar(1000) DEFAULT NULL,
  `reserved1` varchar(255) DEFAULT NULL,
  `reserved2` varchar(255) DEFAULT NULL,
  `reserved3` varchar(255) DEFAULT NULL,
  `reserved4` varchar(255) DEFAULT NULL,
  `reserved5` varchar(255) DEFAULT NULL,
  `reserved6` varchar(255) DEFAULT NULL,
  `reserved7` varchar(255) DEFAULT NULL,
  `reserved8` varchar(255) DEFAULT NULL,
  `reserved9` varchar(255) DEFAULT NULL,
  `reserved10` varchar(255) DEFAULT NULL,
  `reserved11` varchar(255) DEFAULT NULL,
  `reserved12` varchar(255) DEFAULT NULL,
  `reserved13` varchar(255) DEFAULT NULL,
  `reserved14` varchar(255) DEFAULT NULL,
  `reserved15` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_bio`
--

INSERT INTO `user_bio` (`id`, `userId`, `name`, `nickName`, `gender`, `from_where`, `dob`, `relationship_status`, `primary_lang`, `other_lang`, `religion`, `zodiac_sign`, `height`, `complexion`, `hobbies`, `edu_quali`, `profession`, `believes`, `about`, `fav_food`, `fav_travel_destn`, `video_cat_liked`, `reserved1`, `reserved2`, `reserved3`, `reserved4`, `reserved5`, `reserved6`, `reserved7`, `reserved8`, `reserved9`, `reserved10`, `reserved11`, `reserved12`, `reserved13`, `reserved14`, `reserved15`) VALUES
(1, 'saswatikotoky24@gmail.com', 'Saswati Kotoky', 'ksaswati', 'Female', 'dergaon', '24/3/1995', 'Single', 'assamese', 'hindi, english', 'Hindu', 'Sagittarius', '153', 'Light', 'travelling', 'MCA', 'Service', 'hard work', 'hi everyone', 'Indian', 'Home', 'funny', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, 'amarjyoti.gautam@gmail.com', 'Amarjyoti Gautam', 'Dadu', 'Male', 'Jorhat', '3/1/2021', 'Relationship', 'Assamese', 'Hindi, English', 'Hindu', 'Sagittarius', '', 'Olive', 'Watching Movies', 'MCA', 'Self Employed', 'hard work', 'I am Amarjyoti from Jorhat', 'Indian', 'Leh', 'funny', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(5, '+919707868238', '+919707868238', '', 'Gender', '', '', 'Single', '', '', 'Religion', 'Sagittarius', '', 'Complexion', '', '', 'Profession', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(8, '+919859134115', '+919859134115', '', 'Female', 'Jorhat', '18/11/2020', 'Single', 'Assamese', '', 'Religion', 'Sagittarius', '', 'Complexion', '', '', 'Profession', '', '', '', '', 'funny', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(9, '+919101319347', 'John', 'johny', 'Gender', 'Mumbai', '19/11/2020', 'Relationship', 'Assamese', 'Hindi, English', 'Hindu', 'Scorpio', '', 'Light', 'Playing sports', '', 'Business', 'honesty', '', '', '', 'funny', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(10, '+919957664980', 'Shaswatikotoky', 'saswati', 'Female', 'golaghat', '24/3/1995', 'Relationship', 'assamese', 'hindi, english', 'Hindu', 'Sagittarius', '', 'Light', 'singing', 'MCA', 'Service', 'hard work', 'hi everyone', 'indian', 'home', 'food', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(11, 'saswatikotoky@gmail.com', 'kSaswati', 'sass', 'Male', 'dergaon', '24/3/1995', 'Single', 'assamese', 'hindi, english', 'Hindu', 'Sagittarius', '153', 'Light', 'shopping', 'bsc', 'Student', 'abcd', 'hii all', 'hinese', 'paris', 'funny', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(12, 'abelbell.09243@gmail.com', 'Abel Bell', '', 'Gender', '', '', 'In A Relationship', '', '', 'Hindu', 'Capricorn', '', 'Black Brown', '', '', 'Business', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(13, 'tipteapi2020@gmail.com', 'tipteapi', 'tt', 'Female', 'dergaon', '9/12/2020', 'Relationship', 'assamese', 'hindi ,english', 'Hindu', 'Sagittarius', '', 'Fair', '', 'MCA', 'Service', 'hard work', '', 'indian', '', 'drama', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(14, 'bharatidadu47@gmail.com', 'Dadu Bharati', 'dadu', 'Male', 'Jorhat', '31/12/2020', 'Separated', 'Assamese', '', 'Sikh', 'Sagittarius', '', 'Tan Brown', '', '', 'Service', '', '', '', '', 'Music,funny', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(15, 'Sara', 'Sara', '', '', 'Guwahati', '', '', '', '', '', 'Aries', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(16, '+919401930158', 'Savi', '', 'Female', 'Jorhat', '30/1/2021', 'Relationship', 'Assamese', '', 'Religion', 'Sagittarius', '', 'Complexion', '', '', 'Profession', '', '', '', '', 'funny', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(17, 'bhaskarboruah212@gmail.com', 'BHASKAR AXOM', 'Love Guru', 'Male', 'sibsager', '31/12/2001', 'Single', 'Assamese', 'English', 'Hindu', 'Pisces', '5ft', 'Light', 'Traveling', 'B.A.', 'Student', 'love', 'no about', 'mango', 'no', 'other', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(18, '+918486409707', '+918486409707', 'Dhiraj', 'Male', 'Guwahati', '24/1/1993', 'In A Relationship', 'Assamese', 'English', 'Hindu', 'Leo', '', 'Black Brown', 'acting', 'graduate', 'Service', 'Karma', 'bindass', 'mutton biriyani', 'no', 'musical video', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(19, '+918011450980', '+918011450980', 'B K', 'Male', 'Guwahati', '7/2/2021', 'Relationship', 'assamese', '', 'Hindu', 'Virgo', '', 'Complexion', '', '', 'Service', '', '', '', '', 'funny', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(20, '+919101054346', '+919101054346', 'M.A', 'Female', 'india', '7/2/2008', 'Single', 'Assamese', 'Hindi', 'Muslim', 'Cancer', '5', 'Olive', '', 'HS', 'Student', 'Assam', 'BLP', 'Rice', 'dance', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(21, 'purobidey162@gmail.com', 'Purobi Dey', 'Beauty', 'Female', 'jorhat mariani', '28/12/2002', 'In A Relationship', '', '', 'Hindu', 'Scorpio', '5.7', 'Tan Brown', '', '', 'Self Employed', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(22, 'ishanbora710@gmail.com', 'Ishan Bora', '', 'Male', 'Jorhat', '27/5/1987', 'Others', 'Assamese', 'English', 'Hindu', 'Gemini', '180 cm', 'Fair', 'Badminton', 'M. Sc Chemistry', 'Service', 'Karma', '', 'Duck', 'Home', 'Sports', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(23, 'tapankalita89@gmail.com', 'tapan kalita', '', 'Male', '', '1/3/1983', 'Others', 'Assamese', '', 'Religion', 'Libra', '', 'Complexion', '', '', 'Profession', '', '', '', '', 'All', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(24, '+918169734112', 'Sia', 'sia', 'Female', 'India', '26/09/98', 'Relationship', 'Hindi', 'English', 'Religion', 'Scorpio', '', 'Complexion', '', '', 'Profession', '', '', 'Indian', '', 'Drama', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(25, 'jjobillinesrongmithu@gmail.com', 'JS.Rongmithu JS.Rongmithu', '', 'Gender', 'Boko Hahim', '', 'Relationship', '', '', 'Christian', 'Capricorn', '5.6', 'Black Brown', '', '', 'Profession', 'God Christian', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(26, 'anukatzdevil@gmail.com', 'Anurag Katuwal', 'Anu', 'Male', 'golaghat', '8/2/1994', 'Relationship', '', '', 'Religion', 'Leo', '', 'Complexion', '', '', 'Profession', '', '', '', '', 'entertainment', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(27, 'snigdhasenapati106@gmail.com', 'Snigdha Senapty', 'Snigdha', 'Female', 'Assam,Chabua', '1/12/2001', 'Relationship', '', '', 'Hindu', 'Sagittarius', '4.9', 'Tan Brown', '', '', 'Student', 'Karma', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(28, 'kshr006@gmail.com', 'SReYaS BHAI', 'CHIKYA', 'Male', 'Pune', '6/1/2021', 'Single', 'hindi', 'english', 'Hindu', 'Aquarius', '6ft', 'Fair', 'football', 'dangerous', 'Student', 'india', 'nothing', 'samosa', 'india gate', 'all', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(29, '+917640072232', '+917640072232', 'nito', 'Female', 'Meghalaya,Tura', '15/7/1992', 'Single', '', '', 'Christian', 'Cancer', '', 'Fair', '', '', 'Self Employed', '', '', '', 'Switzerland', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(30, 'borotulika3@gmail.com', 'Tulika Boro', '', 'Female', 'Guwahati', '31/7/1998', 'Relationship', '', '', 'Hindu', 'Libra', '', 'Complexion', 'Dance', '', 'Student', '', 'Dancer', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(31, '+916003822496', '+916003822496', 'jannad ali', 'Male', '6003822496', '10/2/2021', 'Single', '6003822496', '', 'Religion', 'Aries', '6003822496', 'Olive', '', '', 'Profession', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(32, '+917041709267', 'VIVEK SHARMA', 'Vicky', 'Male', 'India', '5/2/1999', 'Single', 'Hindi, English', 'Gujarati', 'Religion', 'Virgo', '', 'Complexion', '', '', 'Profession', '', '', '', '', 'Science & Education', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(33, '+917002348927', '+917002348927', 'Bappi', 'Gender', 'Bilasipara', '10/12/1993', 'Relationship', 'Assamese', 'Rajbangshi,goalporiya,Bengali,hindi', 'Muslim', 'Aries', '5.4', 'Fair', 'Photography, travelling, making new friends', '12', 'Others', 'Myself', 'I m from,I love Photography ND done Photoshot', 'chaat', 'long', 'song,short video', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
