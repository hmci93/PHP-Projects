
-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int(20) NOT NULL,
  `category` varchar(1000) NOT NULL,
  `userId` varchar(1000) NOT NULL,
  `dateTime` varchar(1000) NOT NULL,
  `place` varchar(1000) NOT NULL,
  `assetImage` varchar(1000) NOT NULL,
  `reserved1` varchar(1000) DEFAULT NULL,
  `reserved2` varchar(1000) DEFAULT NULL,
  `reserved3` varchar(1000) DEFAULT NULL,
  `reserved4` varchar(1000) DEFAULT NULL,
  `reserved5` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id`, `category`, `userId`, `dateTime`, `place`, `assetImage`, `reserved1`, `reserved2`, `reserved3`, `reserved4`, `reserved5`) VALUES
(1, 'abcd', '1', '09/08/2020 19:20:34', 'dibrugarh', 'uploads/image/organic-tea_1573.jpg', '', '', '', '', ''),
(3, 'comedy', '1', '09/08/2020 22:07:40', 'delhi', 'uploads/image/download(2)_4558.jpg', '', '', '', '', ''),
(4, 'comedy', '24', '09/08/2020 22:23:31', 'delhi', 'uploads/image/download(15)_9089.jpg', '', '', '', '', '');
