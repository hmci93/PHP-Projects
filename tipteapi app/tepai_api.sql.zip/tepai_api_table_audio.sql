
-- --------------------------------------------------------

--
-- Table structure for table `audio`
--

CREATE TABLE `audio` (
  `id` int(20) NOT NULL,
  `category` varchar(1000) NOT NULL,
  `userId` varchar(1000) NOT NULL,
  `dateTime` varchar(1000) NOT NULL,
  `place` varchar(1000) NOT NULL,
  `assetAudio` varchar(1000) NOT NULL,
  `reserved1` varchar(1000) DEFAULT NULL,
  `reserved2` varchar(1000) DEFAULT NULL,
  `reserved3` varchar(1000) DEFAULT NULL,
  `reserved4` varchar(1000) DEFAULT NULL,
  `reserved5` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
