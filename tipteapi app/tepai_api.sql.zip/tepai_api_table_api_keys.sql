
-- --------------------------------------------------------

--
-- Table structure for table `api_keys`
--

CREATE TABLE `api_keys` (
  `ak_id` int(20) NOT NULL,
  `api_key` varchar(500) NOT NULL,
  `reserved1` varchar(255) DEFAULT NULL,
  `reserved2` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `api_keys`
--

INSERT INTO `api_keys` (`ak_id`, `api_key`, `reserved1`, `reserved2`) VALUES
(1, '6adca579a9111ab5af265be8ed52742797f5ae6e67eebcfc793449d63618e7e5', '', ''),
(2, 'b5d9ef0c4bbcc84e809cb0a6a7ddc6e104cc307e098b72cd0ab93dd9f353e6bd', '', ''),
(3, 'cf60e79123de73ad2a67926fa239a3352bfa4590a6813399a92dc2d89c4c18da', '', ''),
(4, '1b367005ef391548f6a399cec591558a629bbdc113b4fa95a010cf9b7b5bf509', '', ''),
(5, '66e113a30dc913582e4ef9bf53e6ee8e4a7cda3e50056dce78f68fb6aa0e56c1', '', ''),
(6, '188300f944f663967f3fa9163f1f708bce9292d88c6f0f4783553d2ae2787e76', '', ''),
(7, 'e769332228bc25d9ba9eedfc257cdbba124e39377ccdd5b4e3ebf624a8beb3aa', '', ''),
(8, 'a13fc617b32262c6b48d5a84eac343a59c94859df8d2017229aa91b624842f3d', '', '');
